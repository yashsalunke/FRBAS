import AttendanceProject

AttendanceProject.fun()
